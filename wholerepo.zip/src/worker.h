#pragma once

#include "mr_tasks.h"
#include <mr_task_factory.h>

#include "masterworker.grpc.pb.h"
#include <grpc++/grpc++.h>

class Service final : public masterworker::MapReduce::Service {
  public:
    Worker *worker;

    grpc::Status Map(grpc::ServerContext *        context,
                     const masterworker::MapData *data,
                     masterworker::MapReply *     reply);

    grpc::Status Reduce(grpc::ServerContext *           context,
                        const masterworker::ReduceData *data,
                        masterworker::ReduceReply *     reply);
};

/* CS6210_TASK: Handle all the task a Worker is supposed to do.
    This is a big task for this project, will test your understanding of map
   reduce */
class Worker {
  public:
    /* DON'T change the function signature of this constructor */
    Worker(std::string ip_addr_port);

    /* DON'T change this function's signature */
    bool run();

    grpc::ServerBuilder  builder;
    Service              service;
    BaseMapperInternal * get_mapper_impl(BaseMapper *mapper);
    BaseReducerInternal *get_reducer_impl(BaseReducer *reducer);
};
