#include "master.h"

#include "masterworker.grpc.pb.h"
#include <grpc++/grpc++.h>

#include <chrono>
#include <cstdio>
#include <cstdlib>
#include <unistd.h>


WorkerClient *Worker_wait(grpc::CompletionQueue &cq) {
    void *response_tag;
    bool  response_received;
    GPR_ASSERT(cq.Next(&response_tag, &response_received));
    GPR_ASSERT(response_received);
    WorkerClient *client = static_cast<WorkerClient *>(response_tag);
    assert(client->status.ok());
    delete client->context;
    return client;
}


WorkerClient::WorkerClient(std::shared_ptr<grpc::Channel> channel,
                           grpc::CompletionQueue *        cq_map,
                           grpc::CompletionQueue *        cq_reduce)
    : stub(masterworker::MapReduce::NewStub(channel)), cq_map(cq_map),
      cq_reduce(cq_reduce), is_free(true) {
}


void WorkerClient::AsyncMap(const FileShard &shard, unsigned int n_outputs) {
    masterworker::MapData request;
    auto                  proto_shard_ptr = new masterworker::MapData_Shard();
    auto &                proto_shard     = *proto_shard_ptr;
    proto_shard.set_size(shard.length);
    proto_shard.set_offset(shard.start);
    for (auto &file : shard.filenames) {
        proto_shard.add_shardfiles(file);
    }
    request.set_allocated_shard(&proto_shard);
    request.set_n_outputs(n_outputs);
    this->context = new grpc::ClientContext;

    std::unique_ptr<grpc::ClientAsyncResponseReader<masterworker::MapReply>>
            rpc(this->stub->PrepareAsyncMap(
                    this->context, request, this->cq_map));
    rpc->StartCall();
    rpc->Finish(&this->map_reply, &this->status, (void *)this);
    this->is_free = false;
}

std::vector<std::string> WorkerClient::WaitMap() {
    std::vector<std::string> outfiles;
    for (int i = 0; i < this->map_reply.outfiles_size(); i++) {
        outfiles.push_back(this->map_reply.outfiles(i));
    }
    this->is_free = true;
    return outfiles;
}

void WorkerClient::AsyncReduce(std::vector<std::string> &infiles,
                               std::string &             outfile) {
    masterworker::ReduceData request;
    request.set_outfile(outfile);
    for (auto &fname : infiles) {
        request.add_infiles(fname);
    }

    this->context = new grpc::ClientContext;
    std::unique_ptr<grpc::ClientAsyncResponseReader<masterworker::ReduceReply>>
            rpc(this->stub->PrepareAsyncReduce(
                    this->context, request, this->cq_reduce));
    rpc->StartCall();
    rpc->Finish(&this->reduce_reply, &this->status, (void *)this);
    this->is_free = false;
}

uint32_t WorkerClient::WaitReduce() {
    auto retval   = this->reduce_reply.count_keys();
    this->is_free = true;
    return retval;
}

/* CS6210_TASK: This is all the information your master will get from the
   framework. You can populate your other class data members here if you want
 */
Master::Master(const MapReduceSpec &         mr_spec,
               const std::vector<FileShard> &file_shards)
    : mr_spec(&mr_spec), file_shards(&file_shards) {
    for (auto &ipaddr : mr_spec.worker_ipaddr_ports) {
        auto channel = grpc::CreateChannel(ipaddr,
                                           grpc::InsecureChannelCredentials());
        this->workers.push_back(
                new WorkerClient(channel, &this->cq_map, &this->cq_reduce));
    }
}


/* CS6210_TASK: Here you go. once this function is called you will complete
 * whole map reduce task and return true if succeeded */

WorkerClient *
handle_map_response(std::vector<std::vector<std::string>> &filenames,
                    unsigned int &                         count,
                    Master *                               thus) {
    auto free_worker = Worker_wait(thus->cq_map);
    auto result      = free_worker->WaitMap();
#if DEBUG
    std::cerr << "Map Result of " << result.size() << " length" << std::endl;
#endif
    filenames.push_back(result);
    count -= 1;
    return free_worker;
}

WorkerClient *handle_reduce_response(unsigned int &count, Master *thus) {
    auto free_worker = Worker_wait(thus->cq_reduce);
    count -= 1;
    return free_worker;
}


bool Master::run() {
    std::vector<std::vector<std::string>> filenames;
    unsigned int                          count_busy = 0;
#if DEBUG
    std::cerr << "Total shards: " << (*this->file_shards).size() << std::endl;
#endif


    for (auto &shard : *this->file_shards) {
        WorkerClient *free_worker = nullptr;
        for (auto worker : this->workers) {
            if (worker->is_free) {
                free_worker = worker;
                break;
            }
        }
        if (!free_worker) {
            free_worker = handle_map_response(filenames, count_busy, this);
        }
        free_worker->AsyncMap(shard, this->mr_spec->n_output_files);
        count_busy += 1;
    }
    while (count_busy) {
        handle_map_response(filenames, count_busy, this);
    }

    assert(!count_busy);


    /* REDUCE NOW -----------------------------------------------------------*/
    std::vector<std::string> outfiles;
#if DEBUG
    std::cerr << "Generating " << this->mr_spec->n_output_files << " outputs"
              << std::endl;
#endif
    for (unsigned int i = 0; i < this->mr_spec->n_output_files; i++) {
        auto folder = realpath(mr_spec->output_dir.c_str(), nullptr);
        auto dest = std::string(folder) + std::string("/") + std::to_string(i)
                    + std::string(".output");

        free(folder);
#if DEBUG
        std::cerr << "Calling for output " << dest << std::endl;
#endif

        outfiles.push_back(dest);
        std::vector<std::string> call_fnames;
        for (auto &fvec : filenames) {
            call_fnames.push_back(fvec[i]);
#if DEBUG
            std::cerr << "\twith " << fvec[i] << std::endl;
#endif
        }

        WorkerClient *free_worker = nullptr;
        for (auto worker : this->workers) {
            if (worker->is_free) {
                free_worker = worker;
                break;
            }
        }
        if (!free_worker) {
            free_worker = handle_reduce_response(count_busy, this);
        }
        free_worker->AsyncReduce(call_fnames, outfiles.back());
        count_busy += 1;
    }
    while (count_busy) {
        handle_reduce_response(count_busy, this);
    }


    for (auto &flist : filenames) {
        for (auto &fname : flist) {
            unlink(fname.c_str());
        }
    }
    return true;
}
