#include "file_shard.h"

#include <cassert>
#include <fstream>
#include <iostream>
#include <limits>
#include <string>

bool shard_files(const MapReduceSpec &   mr_spec,
                 std::vector<FileShard> &fileShards) {
    const auto approx_size = mr_spec.map_kilobytes * 1024;
    FileShard  this_shard;
    this_shard.mr_spec = &mr_spec;
    this_shard.start = this_shard.length = 0;
    this_shard.filenames.clear();

    for (auto fname = mr_spec.input_files.begin();
         fname != mr_spec.input_files.end();
         ++fname) {
        std::ifstream f(*fname);
        this_shard.filenames.push_back(*fname);
        auto file_beg    = f.tellg();
        bool reached_end = false;
        while (!reached_end) {
            auto start = f.tellg();
            assert(start != std::iostream::pos_type(-1));

            if (!this_shard.length) {
                this_shard.filenames.clear();
                this_shard.filenames.push_back(*fname);
                this_shard.start = start - file_beg;
            }

            f.seekg(approx_size - this_shard.length, std::iostream::cur);
            f.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            reached_end = f.eof();
            if (reached_end) { f.seekg(0, std::iostream::end); }
            auto end = f.tellg();
            assert(end != std::iostream::pos_type(-1));
            this_shard.length += end - start;

            if (this_shard.length >= approx_size) {
                fileShards.push_back(this_shard);
                this_shard.length = 0;
            }
        }
    }
    if (this_shard.length) { fileShards.push_back(this_shard); }

    return true;
}
