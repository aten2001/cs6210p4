#include "mr_tasks.h"

#include <cassert>
#include <cstdio>
#include <functional>
#include <iostream>


std::size_t maphash(const std::string &key, std::size_t n_buckets) {
    std::size_t range = 1;
    std::size_t len   = 0;
    while (range < n_buckets) {
        /* Assume characters */
        range *= 26;
        len += 1;
    }
    auto chunk_size = range / n_buckets;

    std::size_t str_rank = 0;
    for (std::size_t i = 0; i < len; i++) {
        str_rank *= 26;
        if (i < key.size()) {
            char c = key[i];
            if ('a' <= c && c <= 'z') {
                c = c - 'a';
            } else if ('A' <= c && c <= 'Z') {
                c = c - 'A';
            } else {
                c = 0;
            }
            str_rank += c;
        }
    }
    auto ret = std::max(std::size_t(0),
                        std::min(n_buckets - 1, str_rank / chunk_size));
    assert(ret < n_buckets);
    return ret;
}

/* CS6210_TASK Implement this function */
BaseMapperInternal::BaseMapperInternal() : output_filenames(), output_files() {
}


/* CS6210_TASK Implement this function */
void BaseMapperInternal::emit(const std::string &key, const std::string &val) {
    this->output_files[maphash(key, this->output_files.size())]
            << key << "\t" << val << std::endl;
}


void BaseMapperInternal::set_state(unsigned int n_outputs) {
    this->output_files.clear();
    this->output_filenames.clear();
    for (unsigned int i = 0; i < n_outputs; i++) {
        std::string   file(std::tmpnam(nullptr));
        std::ofstream stream(file);
#if DEBUG
        std::cerr << "Creating tmp " << file << std::endl;
#endif
        this->output_filenames.push_back(file);
        this->output_files.push_back(std::move(stream));
    }
}


std::vector<std::string> BaseMapperInternal::finalize_and_get_state(void) {
    for (auto &filestream : this->output_files) {
        filestream.close();
    }
    return this->output_filenames;
}


/* CS6210_TASK Implement this function */
BaseReducerInternal::BaseReducerInternal() {
}


/* CS6210_TASK Implement this function */
void BaseReducerInternal::emit(const std::string &key,
                               const std::string &val) {
    this->outfile << key << "\t" << val << std::endl;
}


void BaseReducerInternal::set_state(std::string outfile_name) {
    this->outfile_name = outfile_name;
    this->outfile      = std::ofstream(outfile_name);
    this->emit_count   = 0;
}


uint32_t BaseReducerInternal::finalize_and_get_state(void) {
    this->outfile.close();
    return this->emit_count;
}
