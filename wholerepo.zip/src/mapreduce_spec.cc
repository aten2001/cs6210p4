#include "mapreduce_spec.h"

#include <cassert>
#include <fstream>
#include <iostream>
#include <string>
#include <vector>

bool read_mr_spec_from_config_file(const std::string &config_filename,
                                   MapReduceSpec &    mr_spec) {
    std::ifstream config_file(config_filename);

    for (std::string line; std::getline(config_file, line);) {
        std::size_t equal_pos;
        if ((equal_pos = line.find("=", 0)) != line.npos) {
            auto key = line.substr(0, equal_pos);
            auto val = line.substr(equal_pos + 1, line.npos);
            if (key == "worker_ipaddr_ports") {
                val.push_back(',');
                for (std::size_t pos = 0, prev_pos = 0;
                     ((pos = val.find_first_of(',', prev_pos)) != val.npos);
                     prev_pos = pos + 1) {
                    mr_spec.worker_ipaddr_ports.push_back(
                            val.substr(prev_pos, pos - prev_pos));
                }
            } else if (key == "input_files") {
                val.push_back(',');
                for (std::size_t pos = 0, prev_pos = 0;
                     ((pos = val.find_first_of(',', prev_pos)) != val.npos);
                     prev_pos = pos + 1) {
                    mr_spec.input_files.push_back(
                            val.substr(prev_pos, pos - prev_pos));
                }
            } else if (key == "output_dir") {
                mr_spec.output_dir = val;
            } else if (key == "n_output_files") {
                mr_spec.n_output_files = std::stoul(val);
            } else if (key == "map_kilobytes") {
                mr_spec.map_kilobytes = std::stoull(val);
            } else if (key == "user_id") {
                mr_spec.user_id = val;
            } else if (key == "n_workers") {
                /* pass */
            } else {
                assert(false);
            }
        }
    }
    config_file.close();
    return true;
}
