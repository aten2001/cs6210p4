#pragma once

#include "file_shard.h"
#include "mapreduce_spec.h"

#include "masterworker.grpc.pb.h"
#include <grpc++/grpc++.h>


class WorkerClient {
  public:
    std::unique_ptr<masterworker::MapReduce::Stub> stub;
    grpc::CompletionQueue *                        cq_map;
    grpc::CompletionQueue *                        cq_reduce;
    masterworker::MapReply                         map_reply;
    masterworker::ReduceReply                      reduce_reply;
    grpc::Status                                   status;
    explicit WorkerClient(std::shared_ptr<grpc::Channel> channel,
                          grpc::CompletionQueue *        cq_map,
                          grpc::CompletionQueue *        cq_reduce);
    bool is_free;
    void AsyncMap(const FileShard &shard, unsigned int n_outputs);
    void AsyncReduce(std::vector<std::string> &infiles, std::string &outfile);
    std::vector<std::string> WaitMap();
    uint32_t                 WaitReduce();
    void                     Wait();
    grpc::ClientContext *    context;
};


/* CS6210_TASK: Handle all the bookkeeping that Master is supposed to do.
    This is probably the biggest task for this project, will test your
   understanding of map reduce */
class Master {
  public:
    /* DON'T change the function signature of this constructor */
    Master(const MapReduceSpec &, const std::vector<FileShard> &);

    /* DON'T change this function's signature */
    bool run();

  public:
    const MapReduceSpec *         mr_spec;
    const std::vector<FileShard> *file_shards;
    grpc::CompletionQueue         cq_map;
    grpc::CompletionQueue         cq_reduce;
    std::vector<WorkerClient *>   workers;
};
