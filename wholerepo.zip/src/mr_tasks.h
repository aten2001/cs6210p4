#pragma once

#include <fstream>
#include <iostream>
#include <memory>
#include <string>
#include <vector>

/* CS6210_TASK Implement this data structureas per your implementation.
        You will need this when your worker is running the map task*/
struct BaseMapperInternal {
    /* DON'T change this function's signature */
    BaseMapperInternal();

    /* DON'T change this function's signature */
    void emit(const std::string &key, const std::string &val);

    /* NOW you can add below, data members and member functions as per the need
     * of your implementation*/
    std::vector<std::string>   output_filenames;
    std::vector<std::ofstream> output_files;

    void                     set_state(unsigned int n_outputs);
    std::vector<std::string> finalize_and_get_state(void);
};


/* CS6210_TASK Implement this data structureas per your implementation.
        You will need this when your worker is running the reduce task*/
struct BaseReducerInternal {
    /* DON'T change this function's signature */
    BaseReducerInternal();

    /* DON'T change this function's signature */
    void emit(const std::string &key, const std::string &val);

    /* NOW you can add below, data members and member functions as per the need
     * of your implementation*/
    std::string   outfile_name;
    std::ofstream outfile;
    uint32_t      emit_count;

    void     set_state(std::string outfile_name);
    uint32_t finalize_and_get_state(void);
};
