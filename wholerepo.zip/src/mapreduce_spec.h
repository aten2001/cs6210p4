#pragma once

#include <string>
#include <vector>


/* CS6210_TASK: Create your data structure here for storing spec from the
 * config file */
struct MapReduceSpec {
    std::vector<std::string> worker_ipaddr_ports;
    std::vector<std::string> input_files;
    std::string              output_dir;
    unsigned int             n_output_files;
    std::size_t              map_kilobytes;
    std::string              user_id;
};


/* CS6210_TASK: Populate MapReduceSpec data structure with the specification
 * from the config file */
bool read_mr_spec_from_config_file(const std::string &config_filename,
                                   MapReduceSpec &    mr_spec);

/* CS6210_TASK: validate the specification read from the config file */
static inline bool validate_mr_spec(const MapReduceSpec &mr_spec) {
    (void)mr_spec;
    return true;
}
