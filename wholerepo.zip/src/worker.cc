#include "worker.h"

#include "masterworker.grpc.pb.h"
#include <grpc++/grpc++.h>

#include <algorithm>
#include <sstream>
#include <vector>


extern std::shared_ptr<BaseMapper>
get_mapper_from_task_factory(const std::string &user_id);
extern std::shared_ptr<BaseReducer>
get_reducer_from_task_factory(const std::string &user_id);


grpc::Status Service::Map(grpc::ServerContext *        context,
                          const masterworker::MapData *data,
                          masterworker::MapReply *     reply) {
    (void)context;
    auto mapper = get_mapper_from_task_factory("cs6210");
    auto impl   = this->worker->get_mapper_impl(&*mapper);
    impl->set_state(data->n_outputs());
#if DEBUG
    std::cerr << "NEW MAPCALL " << std::endl;
#endif

    auto              shard     = data->shard();
    std::size_t       size_left = shard.size();
    std::vector<char> shard_buf;
    std::size_t       offset = shard.offset();
    std::vector<char> tmpbuf(size_left);
    for (std::size_t i = 0; int(i) < shard.shardfiles_size(); i++) {
        auto &        filename = shard.shardfiles(i);
        std::ifstream file(filename);
        assert(file.is_open());
        file.seekg(0, std::ios::end);
        auto end = file.tellg();
        file.seekg(offset, std::ios::beg);
        std::size_t file_rem = end - file.tellg();

        while (file.read(tmpbuf.data(), std::min(file_rem, size_left))
               && size_left) {
            auto readlen = file.gcount();
            shard_buf.insert(
                    shard_buf.end(), tmpbuf.begin(), tmpbuf.begin() + readlen);
            size_left -= readlen;
        }
        offset = 0;
    }
    assert(shard_buf.size() == data->shard().size());

    std::istringstream shard_stream(
            std::string(shard_buf.data(), shard_buf.size()));
    while (!shard_stream.eof()) {
        std::string line;
        std::getline(shard_stream, line);
        mapper->map(line);
    }

    auto outfiles = impl->finalize_and_get_state();
    for (auto &filename : outfiles) {
        reply->add_outfiles(filename);
    }
    return grpc::Status::OK;
}


struct compare {
    bool operator()(const std::string &s1, const std::string &s2) const {
        return s1 < s2;
    }
};

grpc::Status Service::Reduce(grpc::ServerContext *           context,
                             const masterworker::ReduceData *data,
                             masterworker::ReduceReply *     reply) {
    (void)context;
    auto reducer = get_reducer_from_task_factory("cs6210");
    auto impl    = this->worker->get_reducer_impl(&*reducer);
    impl->set_state(data->outfile());
#if DEBUG
    std::cerr << "NEW MAPCALL " << std::endl;
    std::cerr << "ReduceOutputFile\t" << data->outfile() << std::endl;
#endif

    std::map<std::string, std::vector<std::string>, compare> kv_map;

    for (int i = 0; i < data->infiles_size(); i++) {
        auto fname = data->infiles(i);

        std::ifstream file(fname);
        while (!file.eof()) {
            std::string key;
            std::string val;
            file >> key >> val;
            if (key.length()) { kv_map[key].push_back(val); }
        }
    }

    for (auto &kv : kv_map) {
        reducer->reduce(kv.first, kv.second);
    }

    auto count = impl->finalize_and_get_state();
    reply->set_count_keys(count);
    return grpc::Status::OK;
}

/* CS6210_TASK: ip_addr_port is the only information you get when started.
    You can populate your other class data members here if you want */
Worker::Worker(std::string ip_addr_port) {
    this->builder.AddListeningPort(ip_addr_port,
                                   grpc::InsecureServerCredentials());
    this->builder.RegisterService(&this->service);
    this->service.worker = this;
}

BaseMapperInternal *Worker::get_mapper_impl(BaseMapper *mapper) {
    return mapper->impl_;
}

BaseReducerInternal *Worker::get_reducer_impl(BaseReducer *reducer) {
    return reducer->impl_;
}


/* CS6210_TASK: Here you go. once this function is called your woker's job is
   to keep looking for new tasks from Master, complete when given one and again
   keep looking for the next one. Note that you have the access to BaseMapper's
   member BaseMapperInternal impl_ and BaseReduer's member BaseReducerInternal
   impl_ directly, so you can manipulate them however you want when running
   map/reduce tasks*/
bool Worker::run() {
    /*  Below 5 lines are just examples of how you will call map and reduce
        Remove them once you start writing your own logic */

    std::unique_ptr<grpc::Server> server(this->builder.BuildAndStart());
    server->Wait();
    return true;
}
